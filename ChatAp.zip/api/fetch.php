<?php
$from = $_GET['from'];
$to = $_GET['to'];
$filename = strtolower("../database/chat/{$from}_{$to}.json");
$filename_alt = strtolower("../database/chat/{$to}_{$from}.json");
if (file_exists($filename_alt)) $filename = $filename_alt;

$data = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
echo json_encode($data);
?>