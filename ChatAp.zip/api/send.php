<?php
$from = $_POST['from'];
$to = $_POST['to'];
$message = $_POST['message'];
$filename = strtolower("../database/chat/{$from}_{$to}.json");
$filename_alt = strtolower("../database/chat/{$to}_{$from}.json");

if (file_exists($filename_alt)) $filename = $filename_alt;

$data = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
$data[] = ['from' => $from, 'text' => $message, 'time' => time()];
file_put_contents($filename, json_encode($data));
?>