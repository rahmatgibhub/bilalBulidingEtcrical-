<?php
$user = $_POST['username'];
$file = '../database/users.json';
$data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
if (in_array($user, $data)) echo 'ok';
else echo 'fail';
?>