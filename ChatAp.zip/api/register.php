<?php
$user = $_POST['username'];
$file = '../database/users.json';
$data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
if (!in_array($user, $data)) {
  $data[] = $user;
  file_put_contents($file, json_encode($data));
}
?>